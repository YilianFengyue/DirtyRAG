"""EvidenceBoard-RAG components."""

